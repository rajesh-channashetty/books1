﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Product.Entity;
using PMS.BL;
using PMS.Exception;

namespace Product.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void ShowData()
        {
            try
            {
                dgproduct.DataContext = Productvalidation.GetAllProducts();
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PProduct_138293 prod = new PProduct_138293();
                prod.Name = txtProdName.Text;
                prod.Price = Convert.ToInt32(txtprice.Text);


                int records = Productvalidation.AddProduct(prod);

                if (records > 0)
                {
                    MessageBox.Show("Product record added successfully");
                    ShowData();
                    
                }
                else
                    throw new ProductException("Product record not added");
            }
            catch (ProductException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
        }
    }
}

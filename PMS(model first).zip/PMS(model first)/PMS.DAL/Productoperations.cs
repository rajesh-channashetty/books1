﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Product.Entity;
using PMS.Exception;

namespace PMS.DAL
{
    public class Productoperations
    {
        static ProductModelContainer context = new ProductModelContainer();

        public static int AddProduct(PProduct_138293 prod)
        {
            int records = 0;

            try 
            {
                context.PProduct_138293.Add(prod);

                records = context.SaveChanges();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        public static List<PProduct_138293> GetAllProducts()
        {
            List<PProduct_138293> prodList = null;

            try
            {
                prodList = context.PProduct_138293 .ToList<PProduct_138293>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodList;
        }

    }
}

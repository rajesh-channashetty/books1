﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS.DAL;
using PMS.Entity;
using PMS.Exception;

namespace PMS.BL
{
    public class Productvalidation
    {
        public static bool validateproduct(PProduct_138293 prod)
        {
            bool validateproduct = true;
            StringBuilder message = new StringBuilder();
            try
            {
                if (prod.Name.Trim() == string.Empty)
                {
                    message.Append("Product name should be provided");
                    validateproduct = false;
                }
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return validateproduct;
        }

        public static int AddProduct(PProduct_138293 prod)
        {
            int records = 0;

            try
            {
                if (validateproduct(prod))
                {
                    records = Productoperations.AddProduct(prod);
                }
                else
                    throw new ProductException("Please provide valid information");
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }
        public static List<PProduct_138293> GetAllProducts()
        {
            List<PProduct_138293> prodList = new List<PProduct_138293>();

            try
            {
                prodList = Productoperations.GetAllProducts();
            }
            catch (ProductException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return prodList;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.DAL;
using sms.entity;

namespace SMS.BL
{
    public class STUDENTVALIDATION
    {
        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;
            recordsAffected = Class1.AddNewStudent(stud);
        
            return recordsAffected;
        }
    }
}

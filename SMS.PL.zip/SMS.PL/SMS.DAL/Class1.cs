﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using sms.entity;

namespace SMS.DAL
{
     
    public class Class1
    {
         
    

        public static int AddNewStudent(Student stud)
	{
        SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_20Sep17_Pune_Batch_II;uid=sqluser;pwd=sqluser;");
               SqlCommand cmd=new SqlCommand();

            cmd.CommandType=CommandType.StoredProcedure;
            cmd.CommandText = "usp_addStudent";
            cmd.Connection = con;
        cmd.Parameters.AddWithValue("@Name", stud.Name);
        cmd.Parameters.AddWithValue("@Course", stud.Course);
        cmd.Connection.Open();
              int  rec = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            
            
		return rec ;
	}

     
            

            
        }
    }
    

  



SELECT * FROM SMS_138242

CREATE PROCEDURE usp_addStudent
	(		
		@Name	nvarchar(20),
		@Course	nvarchar(10)
	
	)
AS
	insert into SMS_138242
	
	values
	(@Name, @Course)
	RETURN

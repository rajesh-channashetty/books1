﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LA.Entity;
using LA.Exception;

public partial class ProfileData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Userclass use = (Userclass)Session["use"];

        txtprloginname.Text = use.LoginName;
        txtpruserfullname.Text = use.UserFullName;
        txtprdob.Text = use.DOB.ToString();
        txtpremailid.Text = use.Email;
        txtprhighestqualification.Text = use.HighQualification;
    }
}
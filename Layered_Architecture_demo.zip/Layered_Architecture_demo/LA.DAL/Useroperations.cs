﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LA.Entity;
using LA.Exception;
using System.Data.SqlClient;

namespace LA.DAL
{
    public class Useroperations
    {
        public static Userclass searchuser(string ln, string pw)
        {
            Userclass use = null;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "[dbo].usp_searchUser_138293";

                cmd.Parameters.AddWithValue("@loginname", ln);
                cmd.Parameters.AddWithValue("@password", pw);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    use = new Userclass();
                    dr.Read();
                    use.LoginName = dr["LoginName"].ToString();
                    use.UserFullName = dr["UserFullName"].ToString();
                    use.Email = dr["Email"].ToString();
                    use.DOB = Convert.ToDateTime(dr["DOB"]);
                    use.HighQualification = dr["HighestQualification"].ToString();
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (UserException ex)
            {
                throw ex;
            }
            return use;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LA.DAL;
using LA.Entity;
using LA.Exception;

namespace LA.BL
{
    public class UserValidations
    {
        public static Userclass searchuser(string ln, string pw)
        {
            Userclass use=null;
            try
            {
                use = Useroperations.searchuser(ln, pw);
            }
            catch(UserException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return use;
        }
    }
}

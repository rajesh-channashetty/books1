﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LA.Entity
{
    public class Userclass
    {
        public string LoginName { get; set; }
        public string UserFullName { get; set; }
        public DateTime DOB { get; set; }
        public string Email { get; set; }
        public string HighQualification { get; set; }
        public string Password { get; set; }
    }
}

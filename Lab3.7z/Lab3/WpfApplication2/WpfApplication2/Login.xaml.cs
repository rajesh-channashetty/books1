﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Collections.ObjectModel;
namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
            listBox.DataContext = st;
        }
        List<Patient> st = new List<Patient>();
        Patient ob1;
        private void buttom_Click(object sender, RoutedEventArgs e)
        {
            ob1 = new Patient();
            ob1.PatientID = Convert.ToInt32(idbox.Text);
            ob1.Patient_Name = Convert.ToString(namebox.Text);
            if (Convert.ToString(typebox.Text) == "IN")
                ob1.Patient_Type = PatientType.IN;
            else
                ob1.Patient_Type = PatientType.OUT;


           st.Add(ob1);
           listBox.Items.Refresh();

           tabControl.SelectedIndex = 1;
           idbox.Text = "";
           namebox.Text = "";
        }

    }
    public enum PatientType
    {
        IN,OUT
    }
    public class Patient
    {
        public  int PatientID { get; set; }
        public string Patient_Name { get; set; }
        public PatientType Patient_Type { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.Reflection;
namespace WpfApplication2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
     //   Patient pobj = new Patient();
        
        public MainWindow()
        {
            InitializeComponent();
         //   this.DataContext = pobj;
        }

      
        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            UserName.Text = String.Empty;
            Password.Clear();
            UserName.Focus();
        }
        int count=0;

        private void Login_Click(object sender, RoutedEventArgs e)
        {

            count++;
                if (UserName.Text == "admin" && Password.Password.ToString() == "admin")
                {
                    
                    // Get the current button.
                Button cmd = (Button)e.OriginalSource;

                // Create an instance of the window named
                // by the current button.
                Type type = this.GetType();
                Assembly assembly = type.Assembly;
                Window win = (Window)assembly.CreateInstance(
               type.Namespace + "." + cmd.Content);
                win.ShowDialog();
                count = 4;
                    
                }
                if (count <3)
                {
                    MessageBox.Show("Please Enter the Correct Credentials\nYou have " + (3 - count) + " tries left");
                    UserName.Text = "";
                    Password.Password = "";
                }

                if(count==3)
                {
                    MessageBox.Show("Terminating the process.");
                    Close();
                }
           
        }
        private bool IsAlphabetic(string s)
        {
            Regex r = new Regex(@"^[a-zA-Z]+$");

            return r.IsMatch(s);
        }
        private void UserName_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {

            if (!IsAlphabetic(e.Text))
                e.Handled = true;
        }

       
    }
}

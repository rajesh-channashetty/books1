﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using GuestPhoneBook.Entity;
using GuestPhoneBook.Exceptions;
using GuestPhoneBook.BL;

namespace GusetPhoneBook.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowData();
        }

        public void ShowData()
        {
            try
            {
                dgStudent.DataContext = GuestValidations.GetAllStudents();
            }
            catch (GuestPhoneBookException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Guest_138251 g = new Guest_138251();
                g.GuestID = Convert.ToInt32(txtStudCode.Text);
                g.GuestName = txtStudName.Text;
                g.GuestContactNumber = txtDeptCode.Text;
                

                int records = GuestValidations.AddGuestBL(g);

                if (records > 0)
                {
                    MessageBox.Show("Guest record added successfully");
                    ShowData();
                    
                }
                else
                    throw new GuestPhoneBookException("Guest record not added");
            }
            catch (GuestPhoneBookException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int gid = Convert.ToInt32(txtStudCode.Text);

                Guest_138251 g = GuestValidations.SearchGuestBL(gid);

                if (g != null)
                {
                    
                    gridStudent.DataContext = g;
                }
                else
                    throw new GuestPhoneBookException("Student record not found");

            }
            catch (GuestPhoneBookException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnCount_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                int count = GuestValidations.CountBL();
                MessageBox.Show("Number of guests whose name starts with A: " + count);
            }
            catch (GuestPhoneBookException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

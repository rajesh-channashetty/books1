﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GuestPhoneBook.Entity;
using GuestPhoneBook.Exceptions;

namespace GuestPhoneBook.DAL
{
    public class GuestDAL
    {
        static GuestContext context = new GuestContext();

        //Add Guest Details
        public static int AddGuest(Guest_138251 g)
        {
            int records = 0;

            try 
            {
                var s = context.Guests.Find(g.GuestID);


                if (s == null)
                {
                    context.Guests.Add(g);
                    records = context.SaveChanges();
                }
                
                  
                    
            }
            
            catch(SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        //Search GuestbyID
        public static Guest_138251 SearchGuest(int id)
        {
            Guest_138251 g = null;

            try 
            {
                g = (from x in context.Guests
                     where x.GuestID == id
                     select x).FirstOrDefault();

            }
                
            catch(SystemException ex)
            {
                throw ex;
            }
            return g;
        }

        //List All Guests
        public static List<Guest_138251> GetAllGuests()
        {
            List<Guest_138251> guestList = null;

            try
            {
                guestList = context.Guests.ToList<Guest_138251>();
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestList;
        }


        //Counting Guests having Name starting with A
        public static int CountGuest()
        {
            int count = 0;
            try
            {
                count = (from x in context.Guests
                         where x.GuestName.StartsWith("A")
                         select x).Count();
                       
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return count;
        }
    }
}

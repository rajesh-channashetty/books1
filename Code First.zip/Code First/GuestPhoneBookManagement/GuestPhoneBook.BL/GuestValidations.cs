﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using GuestPhoneBook.Entity;
using GuestPhoneBook.Exceptions;
using GuestPhoneBook.DAL;

namespace GuestPhoneBook.BL
{
    public class GuestValidations
    {
        private static bool ValidateGuest(Guest_138251 guest)
        {
            StringBuilder sb = new StringBuilder();

            bool validGuest = true;

            if (guest.GuestName == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Guest Name Required");
            }
            if (guest.GuestContactNumber.Length < 10)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }

            if (validGuest == false)
            {
                throw new GuestPhoneBookException(sb.ToString());
            }

            return validGuest;
        }

        public static int AddGuestBL(Guest_138251 guest)
        {
            int records=0;

            try
            {
                if (ValidateGuest(guest))
                {
                    records = GuestDAL.AddGuest(guest);
                }
                 else
                    throw new GuestPhoneBookException("Please provide valid information");
            
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return records;
        }

        
        public static Guest_138251 SearchGuestBL(int searchGuestID)
        {
            Guest_138251 searchedGuest = null;

            try
            {
                searchedGuest = GuestDAL.SearchGuest(searchGuestID);
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return searchedGuest;
        }

        public static List<Guest_138251> GetAllStudents()
        {
            List<Guest_138251> guestList = new List<Guest_138251>();

            try
            {
                guestList = GuestDAL.GetAllGuests();
            }
            catch (GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestList;
        }

        public static int CountBL()
        {
            int count = 0;

            try 
            {
                count = GuestDAL.CountGuest();
            }
            catch(GuestPhoneBookException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return count;
        }
    }
}

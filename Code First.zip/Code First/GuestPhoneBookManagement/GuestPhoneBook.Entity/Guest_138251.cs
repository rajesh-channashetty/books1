﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace GuestPhoneBook.Entity
{
    public class Guest_138251
    {
        [Key]
        public int GuestID { get; set; }
        public string GuestName { get; set; }
        public string GuestContactNumber { get; set; }
    }
}

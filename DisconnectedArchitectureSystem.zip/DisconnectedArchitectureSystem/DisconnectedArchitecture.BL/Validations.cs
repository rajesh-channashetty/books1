﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DisconnectedArchitecture.Entity;
using DisconnectedArchitecture.Exceptions;
using DisconnectedArchitecture.DAL;


namespace DisconnectedArchitecture.BL
{
    public class Validations
    {
        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                
                    recordsAffected = StudentOperations.InsertStudent(stud);
             
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
